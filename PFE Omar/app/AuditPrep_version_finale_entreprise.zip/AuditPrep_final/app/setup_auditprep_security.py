r"""Assistant local de configuration de la sécurité AuditPrep IA.

À lancer depuis la racine du projet :
    cd "C:\PFE Omar"
    conda run -n auditprep python "app\setup_auditprep_security.py"

Le mot de passe utilisateur est transformé en empreinte PBKDF2. Le mot de passe
PostgreSQL reste un secret technique requis par l'application et est enregistré
uniquement dans .streamlit/secrets.toml, fichier à ne jamais partager.
"""

import base64
import getpass
import hashlib
import os
from pathlib import Path


ITERATIONS = 600_000


def toml_string(value):
    return '"' + str(value).replace("\\", "\\\\").replace('"', '\\"') + '"'


def password_hash(password):
    salt = os.urandom(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, ITERATIONS)
    return "pbkdf2_sha256${}${}${}".format(
        ITERATIONS,
        base64.urlsafe_b64encode(salt).decode("ascii"),
        base64.urlsafe_b64encode(digest).decode("ascii"),
    )


def ask_non_empty(label, default=""):
    suffix = f" [{default}]" if default else ""
    while True:
        value = input(f"{label}{suffix} : ").strip()
        if value:
            return value
        if default:
            return default
        print("Cette valeur est obligatoire.")


def ask_password(label):
    while True:
        first = getpass.getpass(f"{label} : ")
        if len(first) < 10:
            print("Utilise au moins 10 caractères.")
            continue
        second = getpass.getpass("Confirmer le mot de passe : ")
        if first != second:
            print("Les deux mots de passe ne correspondent pas.")
            continue
        return first


def collect_account(default_username, default_name, role):
    username = ask_non_empty("Identifiant", default_username).lower()
    display_name = ask_non_empty("Nom affiché", default_name)
    secret = ask_password(f"Mot de passe du compte {username}")
    return {
        "username": username,
        "display_name": display_name,
        "role": role,
        "password_hash": password_hash(secret),
    }


def main():
    print("\n=== Configuration sécurisée AuditPrep IA ===\n")
    project_root = Path.cwd()
    secrets_dir = project_root / ".streamlit"
    secrets_path = secrets_dir / "secrets.toml"

    company_name = ask_non_empty("Nom de l'entreprise", "Convergence")

    print("\nCompte administrateur")
    admin = collect_account("admin", "Administrateur AuditPrep", "Administrateur")
    accounts = [admin]

    add_auditor = input("\nCréer aussi un compte Auditeur ? [o/N] : ").strip().lower()
    if add_auditor in {"o", "oui", "y", "yes"}:
        print("\nCompte auditeur")
        accounts.append(collect_account("auditeur", "Auditeur", "Auditeur"))

    print("\nCompte technique PostgreSQL")
    db_host = ask_non_empty("Hôte", "localhost")
    db_port = int(ask_non_empty("Port", "5432"))
    db_name = ask_non_empty("Base de données", "auditprep_ia")
    db_user = ask_non_empty("Utilisateur PostgreSQL", "postgres")
    db_password = getpass.getpass("Mot de passe PostgreSQL : ")
    if not db_password:
        raise SystemExit("Le mot de passe PostgreSQL est obligatoire.")

    lines = [
        "# Généré localement par setup_auditprep_security.py",
        "# Ne jamais envoyer ce fichier ni l'ajouter à Git.",
        "",
        "[auth]",
        f"company_name = {toml_string(company_name)}",
        "session_timeout_minutes = 60",
        "",
    ]

    for account in accounts:
        lines.extend(
            [
                f"[auth.users.{account['username']}]",
                f"display_name = {toml_string(account['display_name'])}",
                f"role = {toml_string(account['role'])}",
                f"password_hash = {toml_string(account['password_hash'])}",
                "active = true",
                "",
            ]
        )

    lines.extend(
        [
            "[database]",
            f"host = {toml_string(db_host)}",
            f"port = {db_port}",
            f"dbname = {toml_string(db_name)}",
            f"user = {toml_string(db_user)}",
            f"password = {toml_string(db_password)}",
            "",
        ]
    )

    secrets_dir.mkdir(parents=True, exist_ok=True)
    if secrets_path.exists():
        answer = input(f"\n{secrets_path} existe déjà. Le remplacer ? [o/N] : ").strip().lower()
        if answer not in {"o", "oui", "y", "yes"}:
            raise SystemExit("Configuration annulée, aucun fichier modifié.")

    secrets_path.write_text("\n".join(lines), encoding="utf-8")
    print(f"\nConfiguration créée : {secrets_path}")
    print("Tu peux maintenant lancer AuditPrep IA.")


if __name__ == "__main__":
    main()
