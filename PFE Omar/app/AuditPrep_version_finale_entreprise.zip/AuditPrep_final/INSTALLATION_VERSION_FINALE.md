# AuditPrep IA — installation de la version finale entreprise

## Contenu

- `app_dashboard_auditprep_final.py` : application Streamlit finale.
- `setup_auditprep_security.py` : création locale des comptes et des secrets.
- `.streamlit/config.toml` : apparence et configuration Streamlit.
- `.streamlit/secrets.toml.example` : exemple sans aucun véritable secret.
- `.gitignore` : empêche l'ajout accidentel des secrets au dépôt.
- `requirements_auditprep.txt` : dépendances Python nécessaires.

## 1. Copier les fichiers

Place les deux fichiers Python dans `C:\PFE Omar\app`.

À la racine `C:\PFE Omar`, crée le dossier `.streamlit`, puis place-y
`config.toml` et `secrets.toml.example`. Place `.gitignore` à la racine.

## 2. Configurer la connexion sécurisée

Dans PowerShell :

```powershell
cd "C:\PFE Omar"
conda run -n auditprep python "app\setup_auditprep_security.py"
```

Suis les questions affichées. Les mots de passe saisis ne sont pas visibles.
L'outil crée `C:\PFE Omar\.streamlit\secrets.toml`.

Le compte Administrateur peut créer et importer des données. Le compte Auditeur
peut utiliser le parcours de préparation et de génération mais ne peut pas
effectuer les trois opérations administratives protégées.

Si une dépendance manque dans l'environnement Conda :

```powershell
conda run -n auditprep python -m pip install -r "requirements_auditprep.txt"
```

## 3. Lancer l'application

```powershell
cd "C:\PFE Omar"
conda run -n auditprep python -m streamlit run "app\app_dashboard_auditprep_final.py"
```

Ouvre ensuite `http://localhost:8501` si le navigateur ne s'ouvre pas seul.

## 4. Présentation technique du front-end

AuditPrep utilise Streamlit comme framework web front-end. Streamlit génère les
composants HTML et JavaScript nécessaires dans le navigateur. L'application
ajoute une couche HTML/CSS personnalisée pour les cartes, les indicateurs, la
page de connexion, les couleurs, les tableaux et le responsive design.

Il n'existe pas de code Java dans ce projet. Java et JavaScript sont deux
technologies différentes. Aucun JavaScript personnalisé n'était nécessaire au
prototype, car les interactions, formulaires, onglets et mises à jour d'état
sont gérés par Streamlit.

## 5. Limite de déploiement

Cette authentification convient au prototype PFE et à une utilisation interne
contrôlée. Pour une exposition publique, il faudrait également HTTPS, un serveur
inverse, une gestion centralisée des identités ou un SSO, des journaux de
connexion et un compte PostgreSQL aux privilèges minimaux.
